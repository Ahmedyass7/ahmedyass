import { Component, OnInit } from '@angular/core';
import { AdminService, Organization } from '../../services/admin.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  
})
export class DashboardComponent implements OnInit {
  organizations: Organization[] = [];
  loading = false;
  errorMessage = '';

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.getOrganizations();
  }

  getOrganizations(): void {
    this.loading = true;

    this.adminService.getOrganizations().subscribe({
      next: (data) => {
        this.organizations = data;
        this.loading = false;
      },
      error: (error) => {
        this.errorMessage = 'Failed to load organizations';
        this.loading = false;
        console.error(error);
      }
    });
  }
}

