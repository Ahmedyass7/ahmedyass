import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

export interface Organization {
  id: string;
  name: string;
  description?: string;
  email?: string;
  phone?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = 'https://eventora.runasp.net/api';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  getOrganizations(): Observable<Organization[]> {
    const token = this.authService.getToken();
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
    return this.http.get<Organization[]>(`${this.apiUrl}/Admin/organizations`, { headers });
  }
}